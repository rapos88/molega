// A good card width-height ratio is 8:11 in my opinion
var cardWidth = 110;
var cardHeight = 150;
var spaceBetweenCards = 20;
var cardFontSize = 20;
var tableFontSize = 25;
var cardSelectColour = questionCardColour;
var typeOfGame = "Community Judge Game";
var professorLastName = "Viper";
var numOfCardsInHand = 6;
var winByRounds = true;
var numOfRounds = 7;
var roomTableSelectColour = "CADETBLUE";
var handCardColour = "WHITE";
var fontType = "Arial";
var questionCardColour = "BLACK";
var fontColour = "BLACK";
var questionFontColour = "WHEAT";
