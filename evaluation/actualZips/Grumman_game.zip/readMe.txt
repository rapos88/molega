Thanks for generating and downloading Grumman's Community Judge Game!

Important information:
The app.js file is the backend server which controls most game functions. All other
files are intended for use from the client perspective (index.html).

Included with this game in the cardFiles directory are example csv files that contain card
information. For the Community Judge game, each card is its own row. In order
for the game to work properly, any card information should be placed one per row in column 1, as
seen in the example card file. The labels "Questions" and "Answers" MUST stay at the top of each
card file column.

 Do not change the name of any files in the cardFiles directory.
Contents may be changed so long as they follow the above rules.

To Host on a Server:
Link to instructions - https://www.digitalocean.com/community/tutorials/how-to-set-up-a-node-js-application-for-production-on-ubuntu-14-04
Note: Above instructions should only include "Install Node.js" (be sure to install version 12.18.2), "Install PM2", and 
"Manage Application with PM2" (using app.js instead of hello.js). If running app.js results in missing package
errors, run the command "npm install"

This set of game files uses Node.js version 12.18.2
package.json is a file that contains all dependency packages required to run this
game. Use npm install before launching the node app to ensure that everything runs as intended.